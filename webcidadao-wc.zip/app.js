
// Simple SPA-like helpers + localStorage 'backend'
const $ = (sel, ctx=document) => ctx.querySelector(sel);
const $$ = (sel, ctx=document) => Array.from(ctx.querySelectorAll(sel));

const DB = {
  _k: 'webcidadao',
  load(){
    const raw = localStorage.getItem(this._k);
    if(raw) return JSON.parse(raw);
    const seed = seedData();
    localStorage.setItem(this._k, JSON.stringify(seed));
    return seed;
  },
  save(data){ localStorage.setItem(this._k, JSON.stringify(data)); },
  get(){ return this.load(); }
};


// --- Theme handling (light/dark) ---
function applyTheme(t){
  document.documentElement.setAttribute('data-theme', t);
  localStorage.setItem('theme', t);
}
function toggleTheme(){
  const cur = localStorage.getItem('theme') || 'light';
  applyTheme(cur==='light'?'dark':'light');
}
(function initTheme(){
  const t = localStorage.getItem('theme') || 'light';
  applyTheme(t);
})();


// Password strength meter (simple)
function senhaStrength(p){
  let s = 0;
  if(p.length >= 6) s++;
  if(/[A-Z]/.test(p)) s++;
  if(/[a-z]/.test(p)) s++;
  if(/[0-9]/.test(p)) s++;
  if(/[^A-Za-z0-9]/.test(p)) s++;
  return Math.min(s,5);
}


function renderIndicadores(){
  const db = DB.get();
  const el = document.getElementById('indicadores');
  if(!el) return;
  el.innerHTML = `
    <ul style="margin:0;padding-left:18px">
      <li>Total de demandas: <b>${db.demands.length}</b></li>
      <li>Projetos ativos: <b>${db.projetos.length}</b></li>
      <li>Orçamento total: <b>R$ ${numberFmt(db.projetos.reduce((a,p)=>a+p.orcamento,0))}</b></li>
    </ul>
  `;
}
function renderPrestacao(){
  const db = DB.get();
  const el = document.getElementById('prestacao');
  if(!el) return;
  const m = {};
  db.projetos.forEach(p=>{ m[p.secretaria] = (m[p.secretaria]||0) + p.orcamento; });
  el.innerHTML = Object.entries(m).map(([sec, val])=>`<div style="display:flex;justify-content:space-between"><span>${sec}</span><b>R$ ${numberFmt(val)}</b></div>`).join('');
}

function emailExists(email){
  const db = DB.get();
  return db.users.some(u => u.email.toLowerCase() === email.toLowerCase());
}
function createUser({nome, email, senha, papel='cidadao'}){
  const db = DB.get();
  const nextId = Math.max(0, ...db.users.map(u=>u.id)) + 1;
  const user = {id: nextId, nome, email, senha, papel};
  db.users.push(user);
  db.session = {userId:user.id, papel:user.papel};
  DB.save(db);
  return user;
}

function seedData(){
  const demands = [
    {id:1, titulo:'Melhoria na iluminação pública', categoria:'Infraestrutura', prioridade:'Alta', status:'Em análise', statusKey:'pendente', votos:127, criadoEm:'2025-01-15', autor:'Maria Silva', endereco:'Rua das Flores, 123 - Centro', fotos:[], descricao:'Há um buraco grande na Rua das Flores, próximo ao número 123.', historico:['Demanda criada e aguardando análise.']},
    {id:2, titulo:'Criação de área de lazer infantil', categoria:'Lazer', prioridade:'Média', status:'Aprovado', statusKey:'resolvida', votos:89, criadoEm:'2025-01-12', autor:'João Santos', endereco:'Praça Central - Centro', fotos:[], descricao:'Solicitação de espaço de lazer infantil.', historico:['Aprovada pela secretaria.']},
    {id:3, titulo:'Ampliação do posto de saúde', categoria:'Saúde', prioridade:'Alta', status:'Em execução', statusKey:'andamento', votos:203, criadoEm:'2025-01-08', autor:'Ana Costa', endereco:'Rua São João esquina com Av. Brasil', fotos:[], descricao:'Demanda de ampliação do posto de saúde.', historico:['Projeto em execução.']},
  ];
  const users = [
    {id:1, nome:'João da Silva', email:'cidadao@demo.com', senha:'123456', papel:'cidadao'},
    {id:2, nome:'Prefeitura', email:'admin@demo.com', senha:'123456', papel:'admin'}
  ];
  return {users, demands, session:null, projetos:[
    {id:1, nome:'Revitalização da Praça Central', secretaria:'Secretaria de Obras', progresso:75, orcamento:150000},
    {id:2, nome:'Programa Saúde na Escola', secretaria:'Secretaria de Saúde', progresso:45, orcamento:80000}
  ]};
}

function login(email, senha){
  const db = DB.get();
  const u = db.users.find(x=>x.email===email && x.senha===senha);
  if(!u) return null;
  db.session = {userId:u.id, papel:u.papel};
  DB.save(db);
  return u;
}
function logout(){
  const db = DB.get();
  db.session = null; DB.save(db);
  location.href = 'index.html';
}
function getSessionUser(){
  const db = DB.get();
  if(!db.session) return null;
  return db.users.find(u=>u.id===db.session.userId) || null;
}
function guard(roles=[]){
  const u = getSessionUser();
  if(!u || (roles.length && !roles.includes(u.papel))){
    location.href = 'login.html';
  }
  return u;
}

function numberFmt(n){ return new Intl.NumberFormat('pt-BR').format(n); }

// ----------- Pages ------------
const Pages = {

  cadastro: () => {
    const form = document.getElementById('signupForm');
    if(!form) return;
    const msg = document.getElementById('signupMsg');
const pwd1 = document.getElementById('senha');
const meter = document.createElement('div');
meter.id='pwdStrengthBar';
meter.style.height='8px'; meter.style.borderRadius='999px'; meter.style.background='#e5e7eb'; meter.style.overflow='hidden'; meter.style.margin='4px 0 8px';
const bar = document.createElement('span'); bar.style.display='block'; bar.style.height='100%'; bar.style.width='0%'; bar.style.background='var(--success)'; meter.appendChild(bar);
pwd1.parentNode.insertBefore(meter, pwd1.nextSibling);
pwd1.addEventListener('input', ()=>{ const s = senhaStrength(pwd1.value); bar.style.width = (s*20)+'%'; });
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const nome = document.getElementById('nome').value.trim();
      const email = document.getElementById('email').value.trim();
      const senha = document.getElementById('senha').value;
      const senha2 = document.getElementById('senha2').value;
      msg.className = ''; msg.textContent = '';
      if(!nome || !email || !senha || !senha2){
        msg.className = 'alert danger'; msg.textContent = 'Preencha todos os campos.'; return;
      }
      if(senha.length < 6){
        msg.className = 'alert danger'; msg.textContent = 'A senha precisa ter pelo menos 6 caracteres.'; return;
      }
      if(senha !== senha2){
        msg.className = 'alert danger'; msg.textContent = 'As senhas não conferem.'; return;
      }
      if(emailExists(email)){
        msg.className = 'alert danger'; msg.textContent = 'Já existe um cadastro com este e‑mail.'; return;
      }
      // Cria usuário como 'cidadao' e faz login automático
      createUser({nome, email, senha, papel:'cidadao'});
      // Redireciona para o painel do cidadão
      location.href = 'usuario.html';
    });
  },

  home(){
    // no JS needed beyond CTA
    const user = getSessionUser();
    if(user) {
      const btn = $('#ctaGo');
      if(btn){ btn.textContent = 'Ir para o painel'; btn.addEventListener('click',()=>{
        location.href = user.papel==='admin'?'admin.html':'usuario.html';
      });}
    }
  },
  login(){
    const form = $('#loginForm');
    const pwd = $('#pwd');
    const eye = $('#eye');
    eye?.addEventListener('click',()=>{
      pwd.type = pwd.type==='password'?'text':'password';
    });
    form?.addEventListener('submit', (e)=>{
      e.preventDefault();
      const email = $('#email').value.trim();
      const senha = $('#pwd').value.trim();
      const u = login(email, senha);
      const msg = $('#msg'); msg.textContent='';
      if(!u){
        msg.textContent = 'Credenciais inválidas.'; msg.style.color='var(--danger)';
        return;
      }
      location.href = u.papel==='admin'?'admin.html':'usuario.html';
    });
  },
  usuario(){
    const user = guard(['cidadao']);
    $('#username').textContent = user.nome;
    const db = DB.get();
    // KPIs
    $('#kpi-demands').textContent = db.demands.length;
    $('#kpi-projetos').textContent = db.projetos.length;
    $('#kpi-orcamento').textContent = 'R$ ' + numberFmt(db.projetos.reduce((a,p)=>a+p.orcamento,0));
    $('#kpi-part').textContent = '1.2K';

    // Recent demands
    const list = $('#recentList');
    list.innerHTML = db.demands.slice(0,3).map(d=>`
      <div class="card" style="display:flex;justify-content:space-between;align-items:center;gap:10px">
        <div>
          <strong>${d.titulo}</strong>
          <div class="badge ${d.statusKey==='resolvida'?'success':d.statusKey==='andamento'?'info':'warn'}">${d.status}</div>
          <div style="color:var(--muted);font-size:12px">${d.categoria} • ${d.criadoEm}</div>
        </div>
        <div>${d.votos} votos</div>
      </div>
    `).join('');

    // Projetos em andamento
    const proj = $('#projList');
    proj.innerHTML = db.projetos.map(p=>`
      <div class="card">
        <div style="display:flex;justify-content:space-between">
          <div><strong>${p.nome}</strong><div style="color:var(--muted);font-size:12px">${p.secretaria}</div></div>
          <div>R$ ${numberFmt(p.orcamento)}</div>
        </div>
        <div class="progress" style="margin-top:10px"><span style="width:${p.progresso}%"></span></div>
      </div>
    `).join('');

    // Nova demanda (modal simples)
    $('#btnNovaDemanda').addEventListener('click', ()=>{
      $('#newDemand').showModal();
    });
    $('#saveDemand').addEventListener('click', ()=>{
      const titulo = $('#nd_titulo').value.trim();
      const desc = $('#nd_desc').value.trim();
      const cat = $('#nd_cat').value;
      if(!titulo||!desc){ alert('Preencha título e descrição'); return; }
      const db2 = DB.get();
      const nextId = Math.max(0,...db2.demands.map(d=>d.id))+1;
      db2.demands.unshift({id:nextId,titulo,descricao:desc,categoria:cat,prioridade:'Média',status:'Em análise',statusKey:'pendente',votos:0,criadoEm:new Date().toISOString().slice(0,10),autor:user.nome,endereco:'',fotos:[],historico:['Criada pelo cidadão.']});
      DB.save(db2);
      $('#newDemand').close();
      location.reload();
    });
  },
  projetos(){
    const user = getSessionUser() || {papel:'cidadao'};
    if(user.papel!=='admin' && user.papel!=='cidadao'){ location.href='login.html'; return; }
    const db = DB.get();
    const list = document.getElementById('listaProjetos');
    if(!list) return;
    list.innerHTML = db.projetos.map(p=>`
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div><strong>${p.nome}</strong><div style="color:var(--muted);font-size:12px">${p.secretaria}</div></div>
          <div>R$ ${numberFmt(p.orcamento)}</div>
        </div>
        <div class="progress" style="margin-top:10px"><span style="width:${p.progresso}%"></span></div>
      </div>
    `).join('');
  },
  transparencia(){
    const user = getSessionUser() || {papel:'cidadao'};
    if(user.papel!=='admin' && user.papel!=='cidadao'){ location.href='login.html'; return; }
    renderIndicadores();
    renderPrestacao();
    document.getElementById('btnGerarRelatorio')?.addEventListener('click', ()=>{
      alert('Relatório gerado com sucesso! (mock)');
    });
  },
  admin(){
    const user = guard(['admin']);
    $('#adminName').textContent = user.nome;
    const db = DB.get();
    $('#kpi-usuarios').textContent = '3.4K';
    $('#kpi-demandas').textContent = db.demands.length;
    $('#kpi-orc').textContent = 'R$ ' + numberFmt(db.projetos.reduce((a,p)=>a+p.orcamento,0));
    $('#kpi-nps').textContent = '2,4%';
    const tbody = $('#adminDemands');
    tbody.innerHTML = db.demands.map(d=>`
      <tr>
        <td>${d.titulo}</td>
        <td>${d.autor}</td>
        <td><span class="status ${d.statusKey}">${d.status}</span></td>
        <td>${d.prioridade}</td>
        <td>${d.criadoEm}</td>
        <td><button class="btn ghost" data-id="${d.id}">Abrir</button></td>
      </tr>
    `).join('');
    tbody.addEventListener('click', (e)=>{
      const id = e.target.dataset?.id;
      if(id){ localStorage.setItem('currentDemand', id); location.href='tarefa.html'; }
    });
  },
  tarefa(){
    const user = guard(['admin']);
    const id = parseInt(localStorage.getItem('currentDemand')||'0',10);
    const db = DB.get();
    const d = db.demands.find(x=>x.id===id) || db.demands[0];
    $('#d_titulo').textContent = d.titulo;
    $('#d_cidadao').textContent = d.autor;
    $('#d_end').textContent = d.endereco||'Sem endereço';
    $('#d_texto').textContent = d.descricao;
    $('#d_status').textContent = d.status;
    $('#hist').innerHTML = d.historico.map(h=>`<li>${h}</li>`).join('');
    $('#btnResponder').addEventListener('click', ()=>{
      const msg = prompt('Mensagem para o cidadão:');
      if(!msg) return;
      d.historico.push('Resposta: '+msg);
      DB.save(db); location.reload();
    });
    $('#btnAvancar').addEventListener('click', ()=>{
      const next = {pendente:'andamento', andamento:'resolvida', resolvida:'resolvida'}[d.statusKey]||'andamento';
      d.statusKey = next;
      d.status = next==='andamento'?'Em execução': next==='resolvida'?'Resolvida':'Em análise';
      d.historico.push('Status atualizado para: '+d.status);
      DB.save(db); location.reload();
    });
  },
  fila(){
    // Lista de demandas para prefeitura (painel coluna)
    guard(['admin']);
    const db = DB.get();
    const col = $('#fila');
    let data = db.demands;
    const q = document.getElementById('searchDemands');
    q?.addEventListener('input', ()=>{
      const t = q.value.trim().toLowerCase();
      data = db.demands.filter(d=> (d.titulo+d.autor+d.status).toLowerCase().includes(t));
      renderFila();
    });
    function renderFila(){
      col.innerHTML = data.map(d=>`
      <div class="card" style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <strong>${d.titulo}</strong>
          <div style="color:var(--muted);font-size:12px">${d.autor} • ${d.criadoEm}</div>
          <div class="badge ${d.statusKey==='resolvida'?'success':d.statusKey==='andamento'?'info':'warn'}">${d.status}</div>
        </div>
        <button class="btn solid" data-id="${d.id}">Abrir</button>
      </div>
    `).join(''); }
    renderFila();
    col.addEventListener('click', (e)=>{
      const id = e.target.dataset?.id;
      if(id){ localStorage.setItem('currentDemand', id); location.href='tarefa.html'; }
    });
  }
};

// Init by data-page attribute
document.addEventListener('DOMContentLoaded', ()=>{
  const tbtn = document.createElement('button');
  tbtn.id='themeToggle'; tbtn.title='Alternar tema';
  Object.assign(tbtn.style,{position:'fixed',right:'14px',bottom:'14px',padding:'10px 12px',borderRadius:'12px',boxShadow:'var(--shadow)',background:'var(--card)'});
  tbtn.textContent = (localStorage.getItem('theme')||'light')==='light'?'🌙':'☀️';
  tbtn.addEventListener('click', ()=>{ toggleTheme(); tbtn.textContent = (localStorage.getItem('theme')||'light')==='light'?'🌙':'☀️'; });
  document.body.appendChild(tbtn);

  const page = document.body.dataset.page;
  if(Pages[page]) Pages[page]();
  // hook common logout buttons
  $$('#logout').forEach(b=>b.addEventListener('click', logout));
});
